//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by test.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_TEST232CAN_DIALOG           102
#define IDR_MAINFRAME                   128
#define IDD_TEST_DIALOG                 129
#define IDR_MENU1                       130
#define IDC_COMBO_PORT                  1001
#define IDC_COMBO_INDEX                 1001
#define IDC_COMBO_CANIND                1002
#define IDC_BUTTON_CONNECT              1003
#define IDC_BUTTON_VERSION              1004
#define IDC_COMBO_INDEX2                1004
#define IDC_BUTTON_BOARDSTATUS          1005
#define IDC_BUTTON_CANINFO              1006
#define IDC_BUTTON_STARTCAN             1007
#define IDC_BUTTON_RESETCAN             1008
#define IDC_BUTTON_EXITSYS              1009
#define IDC_EDIT_STARTID                1009
#define IDC_BUTTON_CANSTATUS            1010
#define IDC_EDIT_ENDID                  1010
#define IDC_BUTTON_CANREGISTER          1011
#define IDC_EDIT_BTR                    1011
#define IDC_BUTTON_BOARDSER             1012
#define IDC_BUTTON_BOARDTYPE            1013
#define IDC_BUTTON_SETTIME              1014
#define IDC_BUTTON_FMVERSION            1015
#define IDC_COMBO_CANBAUD               1016
#define IDC_BUTTON_CHGCANBAUD           1017
#define IDC_COMBO_232BAUD               1018
#define IDC_BUTTON_CHG232BAUD           1019
#define IDC_EDIT_FILTERPARAMETER        1020
#define IDC_BUTTON_SETFILTER            1021
#define IDC_EDIT_WRITEREGISTER          1022
#define IDC_BUTTON_WRITEREGISTER        1023
#define IDC_EDIT_SENDFRAMEID            1024
#define IDC_BUTTON_SEND                 1025
#define IDC_COMBO_SENDTYPE              1026
#define IDC_COMBO_SENDFRAMETYPE         1027
#define IDC_COMBO_SENDFRAMEFORMAT       1028
#define IDC_EDIT_SENDDATA               1029
#define IDC_EDIT_RESENDTIMES            1030
#define IDC_EDIT_SENDTIMEOUT            1030
#define IDC_EDIT_SENDDELAYTIME          1031
#define IDC_EDIT_READREGISTER           1032
#define IDC_EDIT_READGROUP              1037
#define IDC_EDIT_REGISTERVAL            1038
#define IDC_LIST_INFO                   1039
#define IDC_EDIT_CODE                   3001
#define IDC_EDIT_MASK                   3002
#define IDC_COMBO_FILTERTYPE            3003
#define IDC_COMBO_MODE                  3004
#define IDC_EDIT_TIMING0                3005
#define IDC_COMBO_BAUD                  3005
#define IDC_EDIT_TIMING1                3006
#define IDC_COMBO_FILTER                3006
#define ID_MENU_REFRESH                 32771

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1012
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
