//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;


/*
�����Ǿ���ĵ��ö�̬������������õ��Ƕ�̬���صķ�������Ҫ�����ڳ����ʼ����
ʱ��Ӷ�̬����ȡ�ø��������ĵ�ַ������������Ȼ������Ҫ��ʱ����þͿ����ˣ������
�����˳���ʱ���ͷŵ��򿪵Ķ�̬�������С�
*/

//���ȶ�����Ҫ�õ������ݽṹ
//1.ZLGCANϵ�нӿڿ���Ϣ���������͡�
typedef  struct  _VCI_BOARD_INFO{
		USHORT	hw_Version;
		USHORT	fw_Version;
		USHORT	dr_Version;
		USHORT	in_Version;
		USHORT	irq_Num;
		BYTE	can_Num;
		CHAR	str_Serial_Num[20];
		CHAR	str_hw_Type[40];
		USHORT	Reserved[4];
} VCI_BOARD_INFO,*PVCI_BOARD_INFO;

//2.����CAN��Ϣ֡���������͡�
typedef  struct  _VCI_CAN_OBJ{
	UINT	ID;
	UINT	TimeStamp;
	BYTE	TimeFlag;
	BYTE	SendType;
	BYTE	RemoteFlag;//�Ƿ���Զ��֡
	BYTE	ExternFlag;//�Ƿ�����չ֡
	BYTE	DataLen;
	BYTE	Data[8];
	BYTE	Reserved[3];
}VCI_CAN_OBJ,*PVCI_CAN_OBJ;

//3.����CAN������״̬���������͡�
typedef struct _VCI_CAN_STATUS{
	UCHAR	ErrInterrupt;
	UCHAR	regMode;
	UCHAR	regStatus;
	UCHAR	regALCapture;
	UCHAR	regECCapture; 
	UCHAR	regEWLimit;
	UCHAR	regRECounter; 
	UCHAR	regTECounter;
	DWORD	Reserved;
}VCI_CAN_STATUS,*PVCI_CAN_STATUS;

//4.���������Ϣ���������͡�
typedef struct _ERR_INFO{
		UINT	ErrCode;
		BYTE	Passive_ErrData[3];
		BYTE	ArLost_ErrData;
} VCI_ERR_INFO,*PVCI_ERR_INFO;

//5.�����ʼ��CAN����������
typedef struct _INIT_CONFIG{
	DWORD	AccCode;
	DWORD	AccMask;
	DWORD	Reserved;
	UCHAR	Filter;
	UCHAR	Timing0;
	UCHAR	Timing1;
	UCHAR	Mode;
}VCI_INIT_CONFIG,*PVCI_INIT_CONFIG;


typedef struct _VCI_FILTER_RECORD{
	DWORD ExtFrame;	//�Ƿ�Ϊ��չ֡
	DWORD Start;
	DWORD End;
}VCI_FILTER_RECORD,*PVCI_FILTER_RECORD;

//����������Ҫ����ĺ�������
//����ControlCAN.h�еĺ����������庯��ָ������
//////////////////////////////////////////////////////////////////////////
typedef DWORD (CALLBACK*  LPVCI_OpenDevice)(DWORD,DWORD,DWORD);
typedef DWORD (CALLBACK*  LPVCI_CloseDevice)(DWORD,DWORD);
typedef DWORD (CALLBACK*  LPVCI_InitCan)(DWORD,DWORD,DWORD,PVCI_INIT_CONFIG);

typedef DWORD (CALLBACK*  LPVCI_ReadBoardInfo)(DWORD,DWORD,PVCI_BOARD_INFO);
typedef DWORD (CALLBACK*  LPVCI_ReadErrInfo)(DWORD,DWORD,DWORD,PVCI_ERR_INFO);
typedef DWORD (CALLBACK*  LPVCI_ReadCanStatus)(DWORD,DWORD,DWORD,PVCI_CAN_STATUS);

typedef DWORD (CALLBACK*  LPVCI_GetReference)(DWORD,DWORD,DWORD,DWORD,PVOID);
typedef DWORD (CALLBACK*  LPVCI_SetReference)(DWORD,DWORD,DWORD,DWORD,PVOID);

typedef ULONG (CALLBACK*  LPVCI_GetReceiveNum)(DWORD,DWORD,DWORD);
typedef DWORD (CALLBACK*  LPVCI_ClearBuffer)(DWORD,DWORD,DWORD);

typedef DWORD (CALLBACK*  LPVCI_StartCAN)(DWORD,DWORD,DWORD);
typedef DWORD (CALLBACK*  LPVCI_ResetCAN)(DWORD,DWORD,DWORD);

typedef ULONG (CALLBACK*  LPVCI_Transmit)(DWORD,DWORD,DWORD,PVCI_CAN_OBJ,ULONG);
typedef ULONG (CALLBACK*  LPVCI_Receive)(DWORD,DWORD,DWORD,PVCI_CAN_OBJ,ULONG,INT);
//////////////////////////////////////////////////////////////////////////

HANDLE m_hDLL;//��������򿪵Ķ�̬����

//�ӿں���ָ��
LPVCI_OpenDevice VCI_OpenDevice;
LPVCI_CloseDevice VCI_CloseDevice;
LPVCI_InitCan VCI_InitCAN;
LPVCI_ReadBoardInfo VCI_ReadBoardInfo;
LPVCI_ReadErrInfo VCI_ReadErrInfo;
LPVCI_ReadCanStatus VCI_ReadCanStatus;
LPVCI_GetReference VCI_GetReference;
LPVCI_SetReference VCI_SetReference;
LPVCI_GetReceiveNum VCI_GetReceiveNum;
LPVCI_ClearBuffer VCI_ClearBuffer;
LPVCI_StartCAN VCI_StartCAN;
LPVCI_ResetCAN VCI_ResetCAN;
LPVCI_Transmit VCI_Transmit;
LPVCI_Receive VCI_Receive;


////////////////////////////////////////////////////////////////////////////
DWORD m_devtype=20;//USBCAN-E���ͺ�
DWORD m_devind=0;
DWORD m_cannum=0;
int m_connect=0;
 
const DWORD GCanBrTab[10] = {
	        0x060003, 0x060004, 0x060007,
		0x1C0008, 0x1C0011, 0x160023,
		0x1C002C, 0x1600B3, 0x1C00E0,
		0x1C01C1
};

//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
	m_hDLL = LoadLibrary("ControlCAN.dll");//�򿪶�̬��

	//ȡ�ú�����ַ
	VCI_OpenDevice=(LPVCI_OpenDevice)GetProcAddress(m_hDLL,"VCI_OpenDevice");
	VCI_CloseDevice=(LPVCI_CloseDevice)GetProcAddress(m_hDLL,"VCI_CloseDevice");
	VCI_InitCAN=(LPVCI_InitCan)GetProcAddress(m_hDLL,"VCI_InitCAN");
	VCI_ReadBoardInfo=(LPVCI_ReadBoardInfo)GetProcAddress(m_hDLL,"VCI_ReadBoardInfo");
	VCI_ReadErrInfo=(LPVCI_ReadErrInfo)GetProcAddress(m_hDLL,"VCI_ReadErrInfo");
	VCI_ReadCanStatus=(LPVCI_ReadCanStatus)GetProcAddress(m_hDLL,"VCI_ReadCANStatus");
	VCI_GetReference=(LPVCI_GetReference)GetProcAddress(m_hDLL,"VCI_GetReference");
	VCI_SetReference=(LPVCI_SetReference)GetProcAddress(m_hDLL,"VCI_SetReference");
	VCI_GetReceiveNum=(LPVCI_GetReceiveNum)GetProcAddress(m_hDLL,"VCI_GetReceiveNum");
	VCI_ClearBuffer=(LPVCI_ClearBuffer)GetProcAddress(m_hDLL,"VCI_ClearBuffer");
	VCI_StartCAN=(LPVCI_StartCAN)GetProcAddress(m_hDLL,"VCI_StartCAN");
	VCI_ResetCAN=(LPVCI_ResetCAN)GetProcAddress(m_hDLL,"VCI_ResetCAN");
	VCI_Transmit=(LPVCI_Transmit)GetProcAddress(m_hDLL,"VCI_Transmit");
	VCI_Receive=(LPVCI_Receive)GetProcAddress(m_hDLL,"VCI_Receive");

}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormClose(TObject *Sender, TCloseAction &Action)
{
        if(m_connect==1)
        {
                m_connect=0;
                WaitForSingleObject(m_readhandle,2000);
                m_readhandle=NULL;
                VCI_CloseDevice(m_devtype,m_devind);
        }

        FreeLibrary(m_hDLL);//�ͷŶ�̬����
}
//---------------------------------------------------------------------------




void ReceiveThread(void *param)
{
   TListBox *box=(TListBox*)param;
   VCI_CAN_OBJ receivedata[500];
   VCI_ERR_INFO errinfo;
   int len,i,length;
   AnsiString str,tmpstr;
   while(1)
   {
        if(m_connect==0)
                break;
        Sleep(1);
        length = VCI_GetReceiveNum(m_devtype,m_devind,m_cannum);
        if(length<=0)
        continue;
        len=VCI_Receive(m_devtype,m_devind,m_cannum,receivedata,length,200);
        if(len<=0)
        {
                //ע�⣺���û�ж��������������ô˺�������ȡ����ǰ�Ĵ����룬
                //ǧ����ʡ����һ������ʹ����ܲ���֪����������ʲô��
                VCI_ReadErrInfo(m_devtype,m_devind,m_cannum,&errinfo);
        }
        else
        {
	        for(i=0;i<len;i++)
		{
			str="���յ�����֡:  ";
			if(receivedata[i].TimeFlag==0)
				tmpstr="ʱ���ʶ:��  ";
			else
				tmpstr="ʱ���ʶ:0x"+IntToHex((int)receivedata[i].TimeStamp,8)+" ";
			str+=tmpstr;
			tmpstr="֡ID:0x"+IntToHex((int)receivedata[i].ID,8)+" ";
			str+=tmpstr;
			str+="֡��ʽ:";
			if(receivedata[i].RemoteFlag==0)
				tmpstr="����֡ ";
			else
				tmpstr="Զ��֡ ";
			str+=tmpstr;
			str+="֡����:";
			if(receivedata[i].ExternFlag==0)
				tmpstr="��׼֡ ";
			else
				tmpstr="��չ֡ ";
			str+=tmpstr;
			box->Items->Add(str);
			if(receivedata[i].RemoteFlag==0)
			{
				str="����:";
                                if(receivedata[i].DataLen>8)
                                        receivedata[i].DataLen=8;
				for(int j=0;j<receivedata[i].DataLen;j++)
				{
					tmpstr=IntToHex((int)receivedata[i].Data[j],2)+" ";
					str+=tmpstr;
				}
				box->Items->Add(str);
			}
		}
		box->ItemIndex=box->Items->Count-1;
        }
   }

   _endthread();
}

 
//---------------------------------------------------------------------------

void __fastcall TForm1::ComboBox3Change(TObject *Sender)
{
        //������������
        int CurSel = ComboBox3->ItemIndex;
        if(CurSel==10)
        { //�Զ��岨����
            Edit2->Enabled=true;
        }
        else
        {
            Edit2->Enabled=false;
            Edit2->Text = IntToHex((int)GCanBrTab[CurSel],8) ;
        }

}
//------------------------------------
void __fastcall TForm1::ComboBox8Change(TObject *Sender)
{
        //����ģʽ������
        int CurSel = ComboBox8->ItemIndex;
        if(CurSel!=2)
        { //ʹ���˲�
            Edit3->Enabled=true;
            Edit5->Enabled=true;
        }
        else
        {
            Edit3->Enabled=false;
            Edit5->Enabled=false;
        }


}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button1Click(TObject *Sender)
{
        if(m_connect==1)
        {
                Button1->Caption ="����";
                m_connect=0;
                WaitForSingleObject(m_readhandle,2000);
                m_readhandle=NULL;
                VCI_CloseDevice(m_devtype,m_devind);

                ComboBox3->Enabled=true;
                ComboBox4->Enabled=true;
                ComboBox8->Enabled=true;
                Edit3->Enabled=true;
                Edit5->Enabled=true;
                Edit2->Enabled=true;
                ComboBox3Change(Sender);
                ComboBox8Change(Sender);

                return;
        }
        int index = ComboBox1->ItemIndex;
        int cannum = ComboBox2->ItemIndex;
        int devtype=ComboBox9->ItemIndex;
        if(devtype==0)
        {
             devtype=19;
        }
        else if(devtype==1)
        {
             devtype=20;
        }
        else if(devtype==2)
        {
             devtype=21;
        }
        else if(devtype==3)
        {
             devtype=22;
        }
        else
        {

        }
        m_devtype=devtype;
        VCI_INIT_CONFIG initconfig;
        initconfig.Mode=ComboBox4->ItemIndex;

        if(index>=0&&cannum>=0)
        {
                if(VCI_OpenDevice(m_devtype,index,0)==1)
                {
					int baud= StrToInt("0x"+Edit2->Text);
					if(VCI_SetReference(m_devtype,index,cannum,0,&baud)!=1)
					{
						ShowMessage("��ʼ�������ʴ���");
						VCI_CloseDevice(m_devtype,index);
						return;
					}
					else
					{
						if(VCI_InitCAN(m_devtype,index,cannum,&initconfig)!=1)
						{
							ShowMessage("��ʼ��CAN����");	
							VCI_CloseDevice(m_devtype,index);
							return;
						}
						else
						{
							if (ComboBox8->ItemIndex!=2)//ʹ���˲�
							{
								VCI_FILTER_RECORD filterRecord;
								filterRecord.ExtFrame = ComboBox8->ItemIndex;
								DWORD id;
								id=StrToInt("0x"+Edit3->Text);
								filterRecord.Start = id;
								id=StrToInt("0x"+Edit5->Text);
								filterRecord.End = id;
								//����˲�����
								if(VCI_SetReference(m_devtype, m_devind, cannum, 1, &filterRecord)!=1)
								{
									ShowMessage("����˲�����ʧ��");
									VCI_CloseDevice(m_devtype,index);
									return;

								}
								//ʹ�˲�������Ч
								if (VCI_SetReference(m_devtype, m_devind, cannum, 2, NULL)!=1)
								{
									ShowMessage("�����˲�ʧ��");
									VCI_CloseDevice(m_devtype,index);
									return;
								}
							}
							ComboBox3->Enabled=false;
                                                        ComboBox4->Enabled=false;
                                                        ComboBox8->Enabled=false;
                                                        Edit3->Enabled=false;
                                                        Edit5->Enabled=false;
                                                        Edit2->Enabled=false;

							Button1->Caption ="�Ͽ�";
							m_connect=1;
							m_devind=index;
							m_cannum=cannum;
							m_readhandle=(HANDLE)_beginthread(ReceiveThread,0,(void*)ListBox1);
			
						}
						
					}
                        
                }
                else
                {
                        ShowMessage("�򿪶˿ڴ���");
                }

        }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button2Click(TObject *Sender)
{
        if(m_connect==0)
        {
                ShowMessage("���ȴ򿪶˿�");
                return;
        }
        if(VCI_ResetCAN(m_devtype,m_devind,m_cannum)==1)
        {
                ListBox1->Items->Add("��λCAN�ɹ�");
        }
        else
        {
                ListBox1->Items->Add("��λCANʧ��");
        }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button3Click(TObject *Sender)
{
        if(m_connect==0)
        {
                ShowMessage("���ȴ򿪶˿�");
                return;
        }
        if(VCI_StartCAN(m_devtype,m_devind,m_cannum)==1)
        {
                ListBox1->Items->Add("����CAN�ɹ�");
        }
        else
        {
                ListBox1->Items->Add("����CANʧ��");
        }
}
//---------------------------------------------------------------------------




void __fastcall TForm1::Button6Click(TObject *Sender)
{
        if(m_connect==0)
        {
                ShowMessage("���ȴ򿪶˿�");
                return;
        }
        DWORD i= ComboBox3->ItemIndex;
        if(VCI_SetReference(m_devtype,m_devind,0,1,(PVOID)&i)==1)
        {
                ListBox1->Items->Add("���ĳɹ�");
        }
        else
        {
                ListBox1->Items->Add("����ʧ��");
        }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormCreate(TObject *Sender)
{
      ComboBox1->ItemIndex = 0;
      ComboBox2->ItemIndex = 0;
      ComboBox3->ItemIndex = 0;
      ComboBox4->ItemIndex = 0;
      ComboBox5->ItemIndex = 2;
      ComboBox6->ItemIndex =0;
      ComboBox7->ItemIndex =0;
      ComboBox8->ItemIndex =2;
      ComboBox3Change(Sender);
      ComboBox8Change(Sender);
      ComboBox9->ItemIndex=2;
}
//---------------------------------------------------------------------------


//---------------------------------------------------------------------------

//---------------------------------------------------------------------------


void __fastcall TForm1::Button4Click(TObject *Sender)
{
        if(m_connect==0)
        {
                ShowMessage("���ȴ򿪶˿�");
                return;
        }

        BYTE sendtype,frametype,frameformat;
        DWORD id;
        BYTE data[8];

        sendtype=ComboBox5->ItemIndex;
        frametype=ComboBox6->ItemIndex;
        frameformat=ComboBox7->ItemIndex;
        id=StrToInt("0x"+Edit1->Text);

        AnsiString str=Edit4->Text;
        AnsiString strdata;
        int i,kkk;
        for(i=0;i<8;i++)
        {
                strdata=str.SubString(3*i+1,2);
                strdata=strdata.Trim();
                kkk=strdata.Length();
                if(kkk==0)
                {
                        goto exit;
                }
                data[i]=StrToInt(strdata);
                //sscanf(strdata.c_str(),"%x",data+i);
        }

exit:
        VCI_CAN_OBJ senddata;
        senddata.SendType=sendtype;
        senddata.ExternFlag=frametype;
        senddata.RemoteFlag=frameformat;
        senddata.ID=id;
        senddata.DataLen=i;
        memcpy(senddata.Data,data,i);

        DWORD sendTimeout;
        sendTimeout = StrToInt(Edit6->Text) ;
        VCI_SetReference(m_devtype,m_devind,m_cannum,4,&sendTimeout);
        if(VCI_Transmit(m_devtype,m_devind,m_cannum,&senddata,1)==1)
        {
                ListBox1->Items->Add("���ͳɹ�");
        }
        else
        {
                ListBox1->Items->Add("����ʧ��");
        }

}




//---------------------------------------------------------------------------


