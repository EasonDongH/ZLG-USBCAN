/**************************************************************************/
/* LabWindows/CVI User Interface Resource (UIR) Include File              */
/* Copyright (c) National Instruments 2013. All Rights Reserved.          */
/*                                                                        */
/* WARNING: Do not add to, delete from, or otherwise modify the contents  */
/*          of this include file.                                         */
/**************************************************************************/

#include <userint.h>

#ifdef __cplusplus
    extern "C" {
#endif

     /* Panels and Controls: */

#define  MAIN_PANEL                       1       /* callback function: main_panelCB */
#define  MAIN_PANEL_CAN_CAHENNEL          2       /* control type: ring, callback function: (none) */
#define  MAIN_PANEL_MESSAGE_FORMAT        3       /* control type: ring, callback function: (none) */
#define  MAIN_PANEL_MESSAGE_TYPE          4       /* control type: ring, callback function: (none) */
#define  MAIN_PANEL_TRANSMIT_TYPE         5       /* control type: ring, callback function: (none) */
#define  MAIN_PANEL_DEVICE_TYPE           6       /* control type: ring, callback function: (none) */
#define  MAIN_PANEL_MODE                  7       /* control type: ring, callback function: (none) */
#define  MAIN_PANEL_FILTER                8       /* control type: ring, callback function: (none) */
#define  MAIN_PANEL_BAUDRATE              9       /* control type: ring, callback function: SetBaud */
#define  MAIN_PANEL_REST_CAN              10      /* control type: command, callback function: Reset_Device */
#define  MAIN_PANEL_START_CAN             11      /* control type: command, callback function: Start_Device */
#define  MAIN_PANEL_CAN_CHANNEL_LED       12      /* control type: LED, callback function: (none) */
#define  MAIN_PANEL_DECORATION            13      /* control type: deco, callback function: (none) */
#define  MAIN_PANEL_OPEN_CAN              14      /* control type: command, callback function: Open_Device */
#define  MAIN_PANEL_DEVICE_TYPE_LED       15      /* control type: LED, callback function: (none) */
#define  MAIN_PANEL_RECEIVE_BUFFER        16      /* control type: numeric, callback function: (none) */
#define  MAIN_PANEL_CMD_STOP              17      /* control type: command, callback function: CAN_Stop */
#define  MAIN_PANEL_TRANSMIT_CAN_ID       18      /* control type: numeric, callback function: (none) */
#define  MAIN_PANEL_CLEAR_BUFFER          19      /* control type: command, callback function: Clear_Buffer */
#define  MAIN_PANEL_CMD_TRANSMIT          20      /* control type: command, callback function: CAN_Transmit */
#define  MAIN_PANEL_RECIEVE_TABLE         21      /* control type: table, callback function: (none) */
#define  MAIN_PANEL_EndID                 22      /* control type: numeric, callback function: (none) */
#define  MAIN_PANEL_StartID               23      /* control type: numeric, callback function: (none) */
#define  MAIN_PANEL_TRANSMIT_CAN_MESSAGE  24      /* control type: string, callback function: (none) */
#define  MAIN_PANEL_BTR0                  25      /* control type: numeric, callback function: (none) */
#define  MAIN_PANEL_TEXTMSG               26      /* control type: textMsg, callback function: (none) */


     /* Menu Bars, Menus, and Menu Items: */

          /* (no menu bars in the resource file) */


     /* Callback Prototypes: */

int  CVICALLBACK CAN_Stop(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK CAN_Transmit(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Clear_Buffer(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK main_panelCB(int panel, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Open_Device(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Reset_Device(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK SetBaud(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Start_Device(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);


#ifdef __cplusplus
    }
#endif
