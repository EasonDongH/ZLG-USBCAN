//�ļ�����������Ҫ��ControlCan.dll�ļ���kernerldlls�ļ��к�C�ļ�����ͬһ��Ŀ¼��
#include <ansi_c.h>
#include <formatio.h>
#include <utility.h>
#include <cvirte.h>		
#include <userint.h>
#include "CanDemo.h"
#include "ControlCAN.h"

static int mainPanel;
static int connect=0;
unsigned short int DeviceType;
unsigned short int CANChannel;
static int RowIndex=1;

static void *threadfunctiondata = "����һ�����̶߳�ʱ��ʾ��";
static int startflag = 0;
int CVICALLBACK ThreadFunction(void *functionData);

static VCI_ERR_INFO CANError;
static VCI_CAN_OBJ send[1]={0};
static VCI_CAN_OBJ rec[100] = {0};
void ErrorExit(void);
//-----------------------------------------------------
//������
//chr��Ҫת�����ַ�
//cint������ת������������
//�������ܣ��ַ�ת��Ϊ����
//-----------------------------------------------------
int chartoint(unsigned char chr, unsigned char *cint)
{
	unsigned char cTmp;
	cTmp=chr-48;
	if(cTmp>=0&&cTmp<=9)
	{
		*cint=cTmp;
		return 0;
	}
	cTmp=chr-65;
	if(cTmp>=0&&cTmp<=5)
	{
		*cint=(cTmp+10);
		return 0;
	}
	cTmp=chr-97;
	if(cTmp>=0&&cTmp<=5)
	{
		*cint=(cTmp+10);
		return 0;
	}
	return 1;
}
//-----------------------------------------------------
//������
//str��Ҫת�����ַ���
//data������ת�����������ݴ�
//len:���ݳ���
//�������ܣ��ַ���ת��Ϊ���ݴ�
//-----------------------------------------------------
int strtodata(unsigned char *str, unsigned char *data,int len,int flag)
{
	unsigned char cTmp=0;
	int i=0;
	int j=0;
	for( j=0;j<len;j++)
	{
		if(chartoint(str[i++],&cTmp))//�ַ�תΪ����
			return 1;
		data[j]=cTmp;
		if(chartoint(str[i++],&cTmp))
			return 1;
		data[j]=(data[j]<<4)+cTmp;
		if(flag==1)
			i++;
	}
	return 0;
}

int main (int argc, char *argv[])
{
	int i;
	int threadID;
	
	if (InitCVIRTE (0, argv, 0) == 0)
		return -1;	/* out of memory */
	if ((mainPanel = LoadPanel (0, "CanDemo.uir", MAIN_PANEL)) < 0)
		return -1;
	DisplayPanel (mainPanel);
	//����һ���̺߳���
	
	startflag = 1;
	CmtScheduleThreadPoolFunction (DEFAULT_THREAD_POOL_HANDLE, ThreadFunction,NULL, &threadID);
	RunUserInterface ();
	//�ȴ��߳�ִ�У�ֱ�������
	//DiscardPanel (mainPanel); 
	//CmtWaitForThreadPoolFunctionCompletion (DEFAULT_THREAD_POOL_HANDLE, threadID,OPT_TP_PROCESS_EVENTS_WHILE_WAITING);
	CmtWaitForThreadPoolFunctionCompletion (DEFAULT_THREAD_POOL_HANDLE, threadID,0);
	//�ͷ��̺߳���
	CmtReleaseThreadPoolFunctionID (DEFAULT_THREAD_POOL_HANDLE, threadID);
	DiscardPanel (mainPanel);
	return 0;
}

int CVICALLBACK main_panelCB (int panel, int event, void *callbackData,int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_GOT_FOCUS:

			break;
									   
		case EVENT_LOST_FOCUS:

			break;
		case EVENT_CLOSE:
			startflag = 0;
			GetCtrlVal (mainPanel, MAIN_PANEL_DEVICE_TYPE, &DeviceType);
			VCI_CloseDevice(DeviceType,0);
			QuitUserInterface (0);
			break;
	}
	return 0;
}

int CVICALLBACK Open_Device (int panel, int control, int event,void *callbackData, int eventData1, int eventData2)
{	
	VCI_INIT_CONFIG config;
	unsigned int baudrate;
	int StartID;
	int EndID;
	unsigned short Filter;
	unsigned short Mode;
	VCI_FILTER_RECORD filterRecord;
	switch (event)
	{
		case EVENT_COMMIT:
			if(connect==1)//����������˳�
			{
				return 0;
			}
			GetCtrlVal (mainPanel, MAIN_PANEL_DEVICE_TYPE, &DeviceType);
			GetCtrlVal (mainPanel, MAIN_PANEL_CAN_CAHENNEL, &CANChannel);

			if(VCI_OpenDevice(DeviceType,0,0))									 //���豸
			{
				GetCtrlVal (mainPanel, MAIN_PANEL_BTR0, &baudrate);
				if(VCI_SetReference(DeviceType,0,CANChannel,0,&baudrate)!=1)				//�����豸�Ĳ���	
				{
					MessagePopup("����","���ò����ʲ���ʧ��");
				}

				GetCtrlVal (mainPanel, MAIN_PANEL_StartID, &StartID);	   //�˲���ʼID
				GetCtrlVal (mainPanel, MAIN_PANEL_EndID, &EndID);	   //�˲�����ID
				GetCtrlVal (mainPanel, MAIN_PANEL_FILTER, &Filter);		   //�˲���ʽ
				GetCtrlVal (mainPanel, MAIN_PANEL_MODE, &Mode);			   //ģʽ
				SetCtrlVal (mainPanel, MAIN_PANEL_DEVICE_TYPE_LED, 1);
	            config.Mode=Mode;
				GetCtrlVal (mainPanel, MAIN_PANEL_CAN_CAHENNEL, &CANChannel); 

	            if(!(VCI_InitCAN(DeviceType,0,CANChannel,&config)))                            //��ʼ��
				{
					MessagePopup("����","��ʼ��ʧ��");
				}
				//�˲�����
				if(Filter!=2)
				{
					filterRecord.ExtFrame=Filter;
					filterRecord.Starts = StartID;
					filterRecord.Ends= EndID;
				    if (filterRecord.Starts>filterRecord.Ends)
				    {
					    MessagePopup("����","�˲���Χ��ʼID��Ӧ�ô��ڽ���ID!");
					    VCI_CloseDevice(DeviceType,0);
					    return 0;
				    }
				    //����˲�����
				    VCI_SetReference(DeviceType, 0, CANChannel, 1, &filterRecord);
				    if (VCI_SetReference(DeviceType, 0, CANChannel, 2, NULL)!=1)
				    {
					    MessagePopup("����","�˲�����ʧ��");
					    VCI_CloseDevice(DeviceType,0);
					    return 0;
				    }
				}
			}
			else
			{
				SetCtrlVal (mainPanel, MAIN_PANEL_DEVICE_TYPE_LED, 0);
				MessagePopup("����","Open����");
				VCI_CloseDevice(DeviceType,CANChannel);
				return 0;
			}
			connect=1;
			break;
	}
	return 0;
}

int CVICALLBACK Start_Device (int panel, int control, int event,void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			GetCtrlVal (mainPanel, MAIN_PANEL_DEVICE_TYPE, &DeviceType);
			GetCtrlVal (mainPanel, MAIN_PANEL_CAN_CAHENNEL, &CANChannel);
			if(VCI_StartCAN(DeviceType,0,CANChannel))
			{
				SetCtrlVal (mainPanel, MAIN_PANEL_CAN_CHANNEL_LED, 1);
			}
			else
			{
				MessagePopup("����","Start����");
			}
			break;
	}
	return 0;
}

int CVICALLBACK Reset_Device (int panel, int control, int event,void *callbackData, int eventData1, int eventData2)
{
	int receive=0;
	switch (event)
	{
		case EVENT_COMMIT:
			GetCtrlVal (mainPanel, MAIN_PANEL_DEVICE_TYPE, &DeviceType);
			GetCtrlVal (mainPanel, MAIN_PANEL_CAN_CAHENNEL, &CANChannel);
			receive=VCI_ResetCAN( DeviceType,0, CANChannel);
			if(receive==1)
			{
					SetCtrlVal (mainPanel, MAIN_PANEL_CAN_CHANNEL_LED, 0);
					
			}
			else
			{
					MessagePopup("��ʾ","��λCANʧ��"); 
			}

			break;
	}
	return 0;
}

int CVICALLBACK CAN_Stop (int panel, int control, int event,void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			GetCtrlVal (mainPanel, MAIN_PANEL_DEVICE_TYPE, &DeviceType);
			if(VCI_CloseDevice(DeviceType,0))
			{
				SetCtrlVal (mainPanel, MAIN_PANEL_DEVICE_TYPE_LED, 0);
				SetCtrlVal (mainPanel, MAIN_PANEL_CAN_CHANNEL_LED, 0);
				connect=0;
			}
			else
			{
				MessagePopup("��ʾ","�ر�ʧ��");
			}
			//startflag = 0;
			break;
	}
	return 0;
}

int CVICALLBACK Clear_Buffer (int panel, int control, int event,void *callbackData, int eventData1, int eventData2)
{
	int receive=0;
	switch (event)
	{
		case EVENT_COMMIT:
			GetCtrlVal (mainPanel, MAIN_PANEL_DEVICE_TYPE, &DeviceType);
			GetCtrlVal (mainPanel, MAIN_PANEL_CAN_CAHENNEL, &CANChannel); 
			receive=VCI_ClearBuffer(DeviceType,0, CANChannel);
		    DeleteTableRows (mainPanel, MAIN_PANEL_RECIEVE_TABLE, 1, -1);
			RowIndex=1;
			break;
	}
	return 0;
}

int CVICALLBACK CAN_Transmit (int panel, int control, int event,void *callbackData, int eventData1, int eventData2)
{
	int datalen=0;
	char szData[25]={'\0'};
	unsigned char Data[8]={'\0'};
	int a;
	int GetTransmit;
	int threadID;
	int recLen=0;
	int i,j;
	char s[10];					   //��ʱ����
	unsigned short TRANSMIT_TYPE; //�Է�����
	unsigned short MESSAGE_TYPE;
	unsigned short MESSAGE_FORMAT;
	
	int TRANSMIT_CAN_TEXT_ID=0; //֡ID
	int len;
	int  count;
	switch (event)
	{
		case EVENT_COMMIT:
			
			if (startflag==0||connect==0)
			{
				return 0;
			}
			GetCtrlVal (mainPanel, MAIN_PANEL_TRANSMIT_CAN_ID, &TRANSMIT_CAN_TEXT_ID);  //id
			GetCtrlVal (mainPanel, MAIN_PANEL_TRANSMIT_TYPE, &TRANSMIT_TYPE);			//�Է�����
			GetCtrlVal (mainPanel, MAIN_PANEL_MESSAGE_TYPE, &MESSAGE_TYPE);				//֡����
			GetCtrlVal (mainPanel, MAIN_PANEL_MESSAGE_FORMAT, &MESSAGE_FORMAT);			//֡��ʽ														
			GetCtrlVal (mainPanel, MAIN_PANEL_TRANSMIT_CAN_MESSAGE, szData);				//����
			
			send[0].ID= TRANSMIT_CAN_TEXT_ID;
			send[0].SendType=TRANSMIT_TYPE;
			send[0].RemoteFlag=MESSAGE_FORMAT;
			send[0].ExternFlag= MESSAGE_TYPE;
		
			GetCtrlVal (mainPanel, MAIN_PANEL_DEVICE_TYPE, &DeviceType);
			GetCtrlVal (mainPanel, MAIN_PANEL_CAN_CAHENNEL, &CANChannel); 
			InsertTableRows (mainPanel,MAIN_PANEL_RECIEVE_TABLE,-1,1, -1);
			sprintf(s,"%d",RowIndex); 
			SetTableCellVal (mainPanel, MAIN_PANEL_RECIEVE_TABLE, MakePoint(1,RowIndex), s);

			SetTableCellVal (mainPanel, MAIN_PANEL_RECIEVE_TABLE, MakePoint(2,RowIndex), "����");

			sprintf(s,"%08x",send[0].ID);
			SetTableCellVal (mainPanel, MAIN_PANEL_RECIEVE_TABLE, MakePoint(3,RowIndex), s);

			sprintf(s,"%x",send[0].TimeStamp);
			SetTableCellVal (mainPanel, MAIN_PANEL_RECIEVE_TABLE, MakePoint(4,RowIndex), s);

			sprintf(s,"%d",send[0].TimeFlag);
			SetTableCellVal (mainPanel, MAIN_PANEL_RECIEVE_TABLE, MakePoint(5,RowIndex), s);

			sprintf(s,"%d",send[0].SendType);
			SetTableCellVal (mainPanel, MAIN_PANEL_RECIEVE_TABLE, MakePoint(6,RowIndex), s);

			sprintf(s,"%d",send[0].RemoteFlag);
			SetTableCellVal (mainPanel, MAIN_PANEL_RECIEVE_TABLE, MakePoint(7,RowIndex), s);

			sprintf(s,"%d",send[0].ExternFlag);
			SetTableCellVal (mainPanel, MAIN_PANEL_RECIEVE_TABLE, MakePoint(8,RowIndex), s);

			sprintf(s,"%d",send[0].DataLen);
			SetTableCellVal (mainPanel, MAIN_PANEL_RECIEVE_TABLE, MakePoint(9,RowIndex), s);

			datalen=(strlen(szData)+1)/3;
			send[0].DataLen=datalen; 
			strtodata((unsigned char*)szData,Data,datalen,1);
			for(j=0;j<datalen;j++)
			{
				send[0].Data[j]=Data[j];
			}
			//send[0].Data[datalen]='\0';
			SetTableCellVal (mainPanel, MAIN_PANEL_RECIEVE_TABLE, MakePoint(10,RowIndex), szData);

			RowIndex=RowIndex+1;
			GetTransmit=VCI_Transmit(DeviceType,0,CANChannel,send,1);  	
			break;
	}
	return 0;
}
void ErrorExit(void)
{
	//�ڵ�����Ϣ����ʾ������Ϣ
	//��ʾ�û��Ƿ����¿�ʼ�����˳�
	//����û����¿�ʼ����ִ�д��豸����ʼ��CAN��������CAN
	//����Ժ�ѡ���˳������˳�������
	GetCtrlVal (mainPanel, MAIN_PANEL_DEVICE_TYPE, &DeviceType);
	GetCtrlVal (mainPanel, MAIN_PANEL_CAN_CAHENNEL, &CANChannel); 
	//VCI_ReadErrInfo(DeviceType,0,CANChannel,&CANError);
	//SetCtrlVal (mainPanel, MAIN_PANEL_ERROR, CANError.ErrCode);
	
	//QuitUserInterface (0);	
}

int CVICALLBACK ThreadFunction(void *functionData)
{
	unsigned int recLen = 0;
	int count=0;
	int ReceiveNum=0;
	char s[50];
	int j;
	char str[100]={'\0'};
	char ch[99]={'\0'};
	int len;
	VCI_ERR_INFO errinfo;//��������Ϣ
	while(startflag)
	{
		GetCtrlVal (mainPanel, MAIN_PANEL_DEVICE_TYPE, &DeviceType);
		GetCtrlVal (mainPanel, MAIN_PANEL_CAN_CAHENNEL, &CANChannel);
		ReceiveNum=VCI_GetReceiveNum(DeviceType,0,CANChannel);					   //�ⲽ���ܿ��ޣ��п��Խ�ʡϵͳ��Դ
		if(0==ReceiveNum)
		{
			continue;
		}
		else
		{
			SetCtrlVal (mainPanel, MAIN_PANEL_RECEIVE_BUFFER, ReceiveNum);
		}
		recLen = VCI_Receive(DeviceType,0,CANChannel,rec,ReceiveNum,400);				//
		if((recLen>0) &&(recLen!=0xFFFFFFFF))
		{
			int n;
			for( n = 0; n < ReceiveNum; n++ )
			{
			
			InsertTableRows (mainPanel,MAIN_PANEL_RECIEVE_TABLE,-1,1, -1);
			sprintf(s,"%d",RowIndex); 
			SetTableCellVal (mainPanel, MAIN_PANEL_RECIEVE_TABLE, MakePoint(1,RowIndex), s);
			SetTableCellVal (mainPanel, MAIN_PANEL_RECIEVE_TABLE, MakePoint(2,RowIndex), "����");
			
			sprintf(s,"%08x",rec[n].ID);
		    SetTableCellVal (mainPanel, MAIN_PANEL_RECIEVE_TABLE, MakePoint(3,RowIndex), s);
			
			sprintf(s,"%x",rec[n].TimeStamp);
			SetTableCellVal (mainPanel, MAIN_PANEL_RECIEVE_TABLE, MakePoint(4,RowIndex), s);

			sprintf(s,"%d",rec[n].TimeFlag);
			SetTableCellVal (mainPanel, MAIN_PANEL_RECIEVE_TABLE, MakePoint(5,RowIndex), s);

			sprintf(s,"%d",rec[n].SendType);
			SetTableCellVal (mainPanel, MAIN_PANEL_RECIEVE_TABLE, MakePoint(6,RowIndex), s);

			sprintf(s,"%d",rec[n].RemoteFlag);
			SetTableCellVal (mainPanel, MAIN_PANEL_RECIEVE_TABLE, MakePoint(7,RowIndex), s);

			sprintf(s,"%d",rec[n].ExternFlag);
			SetTableCellVal (mainPanel, MAIN_PANEL_RECIEVE_TABLE, MakePoint(8,RowIndex), s);

			sprintf(s,"%d",rec[n].DataLen);
			SetTableCellVal (mainPanel, MAIN_PANEL_RECIEVE_TABLE, MakePoint(9,RowIndex), s);
			ch[0]='\0';
			if(rec[n].RemoteFlag!=1)
			{
			  sprintf(s,"%02x %02x %02x %02x %02x %02x %02x %02x",rec[n].Data[0],rec[n].Data[1],rec[n].Data[2],rec[n].Data[3],rec[n].Data[4],rec[n].Data[5],rec[n].Data[6],rec[n].Data[7]);
			  SetTableCellVal (mainPanel, MAIN_PANEL_RECIEVE_TABLE, MakePoint(10,RowIndex), s);
			}
			//SetTableCellVal (mainPanel, MAIN_PANEL_RECIEVE_TABLE, MakePoint(10,RowIndex), ch);  

			
			RowIndex=RowIndex+1;
			SetCtrlVal (mainPanel, MAIN_PANEL_RECEIVE_BUFFER, 0);
			}
		
		}
		else
		{
			//ע�⣺���û�ж��������������ô˺�������ȡ����ǰ�Ĵ����룬
			//ǧ����ʡ����һ������ʹ����ܲ���֪����������ʲô��
			VCI_ReadErrInfo(DeviceType,0,CANChannel,&errinfo);
		}
	}
	return 0;
}

int CVICALLBACK SetBaud (int panel, int control, int event,void *callbackData, int eventData1, int eventData2)
{
	unsigned short int baudrate;
	unsigned short int BTR0;
	unsigned short int BTR1;
	GetCtrlVal (mainPanel, MAIN_PANEL_BAUDRATE, &baudrate);
	switch (event)
	{
		case EVENT_COMMIT:
			switch(baudrate)
			{
			case 0:
				SetCtrlVal(mainPanel, MAIN_PANEL_BTR0, 0x060003);
				SetCtrlAttribute(mainPanel,MAIN_PANEL_BTR0,ATTR_DIMMED,1);//����������
				SetCtrlAttribute(mainPanel,MAIN_PANEL_BTR0,ATTR_CTRL_MODE,VAL_INDICATOR);//������ʽ
				break;
			case 1:
				SetCtrlVal(mainPanel, MAIN_PANEL_BTR0, 0x060004);
				SetCtrlAttribute(mainPanel,MAIN_PANEL_BTR0,ATTR_DIMMED,1);//����������
				SetCtrlAttribute(mainPanel,MAIN_PANEL_BTR0,ATTR_CTRL_MODE,VAL_INDICATOR);//������ʽ
				break;
			case 2:
				SetCtrlVal(mainPanel,MAIN_PANEL_BTR0,0x060007);
				SetCtrlAttribute(mainPanel,MAIN_PANEL_BTR0,ATTR_DIMMED,1);//����������
				SetCtrlAttribute(mainPanel,MAIN_PANEL_BTR0,ATTR_CTRL_MODE,VAL_INDICATOR);//������ʽ
				break;
			case 3:
				SetCtrlVal(mainPanel,MAIN_PANEL_BTR0,0x1C0008);
				SetCtrlAttribute(mainPanel,MAIN_PANEL_BTR0,ATTR_DIMMED,1);//����������
				SetCtrlAttribute(mainPanel,MAIN_PANEL_BTR0,ATTR_CTRL_MODE,VAL_INDICATOR);//������ʽ
				break;
			case 4:
				SetCtrlVal(mainPanel,MAIN_PANEL_BTR0,0x1C0011);
				SetCtrlAttribute(mainPanel,MAIN_PANEL_BTR0,ATTR_DIMMED,1);//����������
				SetCtrlAttribute(mainPanel,MAIN_PANEL_BTR0,ATTR_CTRL_MODE,VAL_INDICATOR);//������ʽ
				break;
			case 5:
				SetCtrlVal(mainPanel,MAIN_PANEL_BTR0,0x160023);
				SetCtrlAttribute(mainPanel,MAIN_PANEL_BTR0,ATTR_DIMMED,1);//����������
				SetCtrlAttribute(mainPanel,MAIN_PANEL_BTR0,ATTR_CTRL_MODE,VAL_INDICATOR);//������ʽ
				break;
			case 6:
				SetCtrlVal(mainPanel,MAIN_PANEL_BTR0,0x1C002C);
				SetCtrlAttribute(mainPanel,MAIN_PANEL_BTR0,ATTR_DIMMED,1);//����������
				SetCtrlAttribute(mainPanel,MAIN_PANEL_BTR0,ATTR_CTRL_MODE,VAL_INDICATOR);//������ʽ
				break;
			case 7:
				SetCtrlVal(mainPanel,MAIN_PANEL_BTR0,0x1600B3);
				SetCtrlAttribute(mainPanel,MAIN_PANEL_BTR0,ATTR_DIMMED,1);//����������
				SetCtrlAttribute(mainPanel,MAIN_PANEL_BTR0,ATTR_CTRL_MODE,VAL_INDICATOR);//������ʽ
				break;
			case 8:
				SetCtrlVal(mainPanel,MAIN_PANEL_BTR0,0x1C00E0);
				SetCtrlAttribute(mainPanel,MAIN_PANEL_BTR0,ATTR_DIMMED,1);//����������
				SetCtrlAttribute(mainPanel,MAIN_PANEL_BTR0,ATTR_CTRL_MODE,VAL_INDICATOR);//������ʽ
				break;
			case 9:
				SetCtrlVal(mainPanel,MAIN_PANEL_BTR0,0x1C01C1);
				SetCtrlAttribute(mainPanel,MAIN_PANEL_BTR0,ATTR_DIMMED,1);//����������
				SetCtrlAttribute(mainPanel,MAIN_PANEL_BTR0,ATTR_CTRL_MODE,VAL_INDICATOR);//������ʽ
				break;
			case 10:
				SetCtrlVal(mainPanel,MAIN_PANEL_BTR0,0);
				SetCtrlAttribute(mainPanel,MAIN_PANEL_BTR0,ATTR_DIMMED,0);//����������
				SetCtrlAttribute(mainPanel,MAIN_PANEL_BTR0,ATTR_CTRL_MODE,VAL_NORMAL);//������ʽ
				break;
			default:
				SetCtrlVal(mainPanel,MAIN_PANEL_BTR0,0);
			}
			break;
	}
	return 0;
}
