#include "mex.h"
#include"ControlCAN.h"
#pragma comment(lib,"ControlCAN.lib")
//VCI_SetReference0.cpp
void mexFunction(int nlhs, mxArray *plhs[],int nrhs, const mxArray *prhs[])
{
	double DevType;
    double DevIndex;
	double CANIndex;
	double RefType;
	double *output;
	int pData;
	if( nrhs != 5)
	{
		mexErrMsgTxt("not right input");
	}
	DevType = *((double*)mxGetPr(prhs[0]));
	DevIndex = *((double*)mxGetPr(prhs[1]));
	CANIndex = *((double*)mxGetPr(prhs[2]));
	RefType = *((double*)mxGetPr(prhs[3]));
    pData =(int)(*((double*)mxGetPr(prhs[4])));
	nlhs =1;
	plhs[0]=mxCreateDoubleMatrix(1,1,mxREAL);
	output =(double*)mxGetPr(plhs[0]);
	*output=VCI_SetReference(DevType,DevIndex,CANIndex,RefType,&pData);
}
