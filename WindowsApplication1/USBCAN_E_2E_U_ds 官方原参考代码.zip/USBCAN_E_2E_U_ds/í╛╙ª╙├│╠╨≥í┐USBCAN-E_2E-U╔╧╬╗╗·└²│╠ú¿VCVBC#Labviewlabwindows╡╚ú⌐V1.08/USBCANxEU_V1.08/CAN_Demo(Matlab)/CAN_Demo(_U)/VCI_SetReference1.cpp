#include "mex.h"
#include"ControlCAN.h"
#pragma comment(lib,"ControlCAN.lib")
//VCI_SetReference1.cpp��Ҫ��������_Uϵ�е�����˲�����
void mexFunction(int nlhs, mxArray *plhs[],int nrhs, const mxArray *prhs[])
{
	if( nrhs != 7)  //�ж���������ĸ���
	{
		mexErrMsgTxt("���������������!");
	}
	double DevType  =*((double*)mxGetPr(prhs[0]));
	double DevIndex =*((double*)mxGetPr(prhs[1]));
	double CANIndex =*((double*)mxGetPr(prhs[2]));
	double RefType  =*((double*)mxGetPr(prhs[3]));
	double ExtFrame =*((double*)mxGetPr(prhs[4]));
    double Start    =*((double*)mxGetPr(prhs[5]));
	double End      =*((double*)mxGetPr(prhs[6]));
	nlhs =1;
	plhs[0]=mxCreateDoubleMatrix(1,1,mxREAL);
	double *output =(double*)mxGetPr(plhs[0]);
	PVCI_FILTER_RECORD ptVCI_FILTER_RECORD = new VCI_FILTER_RECORD;
	ptVCI_FILTER_RECORD->ExtFrame = ExtFrame;
	ptVCI_FILTER_RECORD->Start    = Start;
	ptVCI_FILTER_RECORD->End      = End;
	*output=VCI_SetReference(DevType,DevIndex,CANIndex,RefType,ptVCI_FILTER_RECORD);
	delete ptVCI_FILTER_RECORD;
}
