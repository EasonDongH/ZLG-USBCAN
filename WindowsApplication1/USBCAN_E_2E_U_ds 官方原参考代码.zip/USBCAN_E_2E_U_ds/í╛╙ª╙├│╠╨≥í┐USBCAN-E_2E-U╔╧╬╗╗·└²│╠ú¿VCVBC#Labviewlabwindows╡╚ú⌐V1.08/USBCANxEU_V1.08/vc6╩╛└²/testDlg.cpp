// testDlg.cpp : implementation file
//

#include "stdafx.h"
#include "test.h"
#include "testDlg.h"
#include "ControlCAN.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

const DWORD GCanBrTab[10] = {
	0x060003, 0x060004, 0x060007,
		0x1C0008, 0x1C0011, 0x160023,
		0x1C002C, 0x1600B3, 0x1C00E0,
		0x1C01C1
};

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestDlg dialog

CTestDlg::CTestDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTestDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTestDlg)
	m_EditSendData = _T("");
	m_EditSendFrmID = _T("");
	m_strStartID = _T("00000000");
	m_strEndID	 = _T("00000000");
	m_strBTR = _T("");
	m_sendTimeout = 1000;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_connect=0;
	m_cannum=0;
	m_devtype=VCI_USBCAN_2E_U;
	m_strBTR.Format("%08x",GCanBrTab[0]);

}

void CTestDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTestDlg)
	DDX_Control(pDX, IDC_COMBO_INDEX2, m_ComboDevType);
	DDX_Control(pDX, IDC_COMBO_FILTER, m_ComboFilterMode);
	DDX_Control(pDX, IDC_COMBO_BAUD, m_ComboBaud);
	DDX_Control(pDX, IDC_COMBO_MODE, m_ComboMode);
	DDX_Control(pDX, IDC_COMBO_CANIND, m_ComboCANInd);
	DDX_Control(pDX, IDC_COMBO_INDEX, m_ComboIndex);
	DDX_Control(pDX, IDC_LIST_INFO, m_ListInfo);
	DDX_Control(pDX, IDC_COMBO_SENDTYPE, m_ComboSendType);
	DDX_Control(pDX, IDC_COMBO_SENDFRAMETYPE, m_ComboSendFrmType);
	DDX_Control(pDX, IDC_COMBO_SENDFRAMEFORMAT, m_ComboSendFrmFmt);
	DDX_Text(pDX, IDC_EDIT_SENDDATA, m_EditSendData);
	DDX_Text(pDX, IDC_EDIT_SENDFRAMEID, m_EditSendFrmID);
	DDX_Text(pDX, IDC_EDIT_STARTID, m_strStartID);
	DDX_Text(pDX, IDC_EDIT_ENDID, m_strEndID);
	DDX_Text(pDX, IDC_EDIT_BTR, m_strBTR);
	DDX_Text(pDX, IDC_EDIT_SENDTIMEOUT, m_sendTimeout);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CTestDlg, CDialog)
	//{{AFX_MSG_MAP(CTestDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON_CONNECT, OnButtonConnect)
	ON_BN_CLICKED(IDC_BUTTON_STARTCAN, OnButtonStartcan)
	ON_BN_CLICKED(IDC_BUTTON_RESETCAN, OnButtonResetcan)
	ON_BN_CLICKED(IDC_BUTTON_SEND, OnButtonSend)
	//ON_COMMAND(ID_MENU_REFRESH, OnMenuRefresh)
	ON_CBN_SELCHANGE(IDC_COMBO_FILTER, OnSelchangeComboFilter)
	ON_CBN_SELCHANGE(IDC_COMBO_BAUD, OnSelchangeComboBaud)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestDlg message handlers

BOOL CTestDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here
	m_ComboSendType.SetCurSel(2);
	m_ComboSendFrmType.SetCurSel(1);
	m_ComboSendFrmFmt.SetCurSel(0);
	m_ComboBaud.SetCurSel(0);
	OnSelchangeComboBaud();
	m_ComboFilterMode.SetCurSel(2);
	OnSelchangeComboFilter();
	
	m_EditSendFrmID="00000080";
	m_EditSendData="01 02 03 04 05 06 07 08 ";
	
	CString str;
	
	m_ComboDevType.AddString("PCI_5010_U");
	m_ComboDevType.AddString("USBCAN_E_U");
	m_ComboDevType.AddString("USBCAN_2E_U");
	m_ComboDevType.AddString("PCI_5020_U");
	m_ComboDevType.SetCurSel(1);
	for(int i=0;i<8;i++)
	{
		str.Format("%d",i);
		m_ComboIndex.AddString(str);
	}
	for(i=0;i<2;i++)
	{
		str.Format("%d",i);
		m_ComboCANInd.AddString(str);
	}
	
	m_ComboIndex.SetCurSel(0);
	m_ComboCANInd.SetCurSel(0);
	m_ComboMode.SetCurSel(0);
	
	UpdateData(false);
	InitializeCriticalSection(&m_Section);
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CTestDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CTestDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CTestDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CTestDlg::OnCancel() 
{
	// TODO: Add extra cleanup here
	int connect=m_connect;
	m_connect=0;
	if(connect)
	{
		Sleep(500);		
		VCI_CloseDevice(m_devtype,m_devind);
	}
	DeleteCriticalSection(&m_Section);
	CDialog::OnCancel();
}

void CTestDlg::OnOK() 
{
	// TODO: Add extra validation here
	int connect=m_connect;
	m_connect=0;
	Sleep(100);
	if(connect)
		VCI_CloseDevice(m_devtype,m_devind);
	
	DeleteCriticalSection(&m_Section);
	CDialog::OnOK();
}

void CTestDlg::OnButtonConnect() 
{
	// TODO: Add your control notification handler code here
	if(m_connect==1)
	{
		m_connect=0;
		Sleep(500);
		GetDlgItem(IDC_EDIT_BTR)->EnableWindow(!m_connect);
		GetDlgItem(IDC_EDIT_STARTID)->EnableWindow(!m_connect);
		GetDlgItem(IDC_EDIT_ENDID)->EnableWindow(!m_connect);
		GetDlgItem(IDC_COMBO_BAUD)->EnableWindow(!m_connect);
		GetDlgItem(IDC_COMBO_FILTER)->EnableWindow(!m_connect);
		GetDlgItem(IDC_COMBO_MODE)->EnableWindow(!m_connect);
		OnSelchangeComboBaud();
		OnSelchangeComboFilter();
		GetDlgItem(IDC_BUTTON_CONNECT)->SetWindowText("����");
		VCI_CloseDevice(m_devtype,m_devind);
		return;
	}

	VCI_INIT_CONFIG init_config;
	int index,mode,cannum,baud,DevType;
	
	UpdateData(true);
	DevType=m_ComboDevType.GetCurSel();
	if (0==DevType)
	{
		DevType=19;
	}
	else if (1==DevType)
	{
		DevType=20;
	}
	else if(2==DevType)
	{
		DevType=21;
	}
	else
	{
		DevType=22;
	}
	m_devtype=DevType;


	index=m_ComboIndex.GetCurSel();
	mode=m_ComboMode.GetCurSel();
	cannum=m_ComboCANInd.GetCurSel();
	sscanf(m_strBTR, _T("%x"), &baud);

	m_devind=index;
	m_cannum=cannum;
	UpdateData(false);

	init_config.Mode=mode;
	
	
	if(VCI_OpenDevice(m_devtype,index,0)!=STATUS_OK)
	{
		MessageBox("���豸ʧ��!","����",MB_OK|MB_ICONQUESTION);
		return;
	}
	if (VCI_SetReference(m_devtype,index, cannum, 0, &baud) != STATUS_OK)
	{
		MessageBox(_T("���ò����ʴ��󣬴��豸ʧ��!"), _T("����"), MB_OK | MB_ICONQUESTION);
		VCI_CloseDevice(m_devtype,index);
		return;
	}
	if(VCI_InitCAN(m_devtype,index,cannum,&init_config)!=STATUS_OK)
	{
		MessageBox("��ʼ��CANʧ��!","����",MB_OK|MB_ICONQUESTION);
		VCI_CloseDevice(m_devtype,index);
		return;
	}
	//�˲�����
	DWORD filterMode=m_ComboFilterMode.GetCurSel();
	if (filterMode!=2)
	{
		VCI_FILTER_RECORD filterRecord;	
		filterRecord.ExtFrame=filterMode;
		UpdateData(TRUE);
		DWORD IDtemp;
		IDtemp=strtol(m_strStartID,NULL,16);
		//_stscanf_s(m_strStartID, _T("%d"), &IDtemp);
		filterRecord.Start = IDtemp;
		IDtemp=strtol(m_strEndID,NULL,16);
		//_stscanf_s(m_strEndID, _T("%d"), &IDtemp);
		filterRecord.End= IDtemp;
		if (filterRecord.Start>filterRecord.End)
		{
			MessageBox(_T("�˲���Χ��ʼID��Ӧ�ô��ڽ���ID!"), _T("����"), MB_OK | MB_ICONQUESTION);
			VCI_CloseDevice(m_devtype,index);
			return;
		}
		//����˲�����
		VCI_SetReference(m_devtype, m_devind, cannum, 1, &filterRecord);
		//ʹ�˲�������Ч
		if (VCI_SetReference(m_devtype, m_devind, cannum, 2, NULL)!=STATUS_OK)
		{
			MessageBox(_T("�����˲�ʧ��!"), _T("����"), MB_OK | MB_ICONQUESTION);
			VCI_CloseDevice(m_devtype,index);
			return;
		}
	}

	m_connect=1;
	
	GetDlgItem(IDC_EDIT_BTR)->EnableWindow(!m_connect);
	GetDlgItem(IDC_EDIT_STARTID)->EnableWindow(!m_connect);
	GetDlgItem(IDC_EDIT_ENDID)->EnableWindow(!m_connect);
	GetDlgItem(IDC_COMBO_BAUD)->EnableWindow(!m_connect);
	GetDlgItem(IDC_COMBO_FILTER)->EnableWindow(!m_connect);
	GetDlgItem(IDC_COMBO_MODE)->EnableWindow(!m_connect);

	GetDlgItem(IDC_BUTTON_CONNECT)->SetWindowText("�Ͽ�");
	
	AfxBeginThread(ReceiveThread,this);
}

void CTestDlg::OnButtonStartcan() 
{
	// TODO: Add your control notification handler code here
	if(m_connect==0)
		return;
	if(VCI_StartCAN(m_devtype,m_devind,m_cannum)==1)
	{
		ShowInfo("�����ɹ�",0);		
	}
	else
	{
		CString str;
		str="����ʧ��";
		ShowInfo(str,2);
	}

}

void CTestDlg::OnButtonResetcan() 
{
	// TODO: Add your control notification handler code here
	if(m_connect==0)
		return;
	if(VCI_ResetCAN(m_devtype,m_devind,m_cannum)==1)
	{
		//GetDlgItem(IDC_BUTTON_STARTCAN)->EnableWindow(true);
		ShowInfo("��λ�ɹ�",0);		
	}
	else
	{
		CString str;
		str="��λʧ��";
		ShowInfo(str,2);
	}
	
}

void CTestDlg::OnButtonSend() 
{
	// TODO: Add your control notification handler code here
	if(m_connect==0)
		return;
	VCI_CAN_OBJ frameinfo;
	char szFrameID[9];
	unsigned char FrameID[4]={0,0,0,0};
	memset(szFrameID,'0',9);
	unsigned char Data[8];
	char szData[25];
	BYTE datalen=0;
	
	UpdateData(true);
	if(m_EditSendFrmID.GetLength()==0||
		(m_EditSendData.GetLength()==0&&m_ComboSendFrmType.GetCurSel()==0))
	{
		ShowInfo("����������",1);
		return;
	}
	
	if(m_EditSendFrmID.GetLength()>8)
	{
		ShowInfo("IDֵ������Χ",1);
		return;
	}
	if(m_EditSendData.GetLength()>24)
	{
		ShowInfo("���ݳ��ȳ�����Χ,���Ϊ8���ֽ�",1);
		return;
	}
	if(m_ComboSendFrmType.GetCurSel()==0)
	{
		if(m_EditSendData.GetLength()%3==1)
		{
			ShowInfo("���ݸ�ʽ����,����������",1);
			return;		
		}		
	}
	memcpy(&szFrameID[8-m_EditSendFrmID.GetLength()],(LPCTSTR)m_EditSendFrmID,m_EditSendFrmID.GetLength());
	strtodata((unsigned char*)szFrameID,FrameID,4,0);

	datalen=(m_EditSendData.GetLength()+1)/3;
	strcpy(szData,(LPCTSTR)m_EditSendData);
	strtodata((unsigned char*)szData,Data,datalen,1);


	UpdateData(false);
	
	frameinfo.DataLen=datalen;
	memcpy(&frameinfo.Data,Data,datalen);

	frameinfo.RemoteFlag=m_ComboSendFrmFmt.GetCurSel();
	frameinfo.ExternFlag=m_ComboSendFrmType.GetCurSel();
	if(frameinfo.ExternFlag==1)
	{
		frameinfo.ID=((DWORD)FrameID[0]<<24)+((DWORD)FrameID[1]<<16)+((DWORD)FrameID[2]<<8)+
			((DWORD)FrameID[3]);
	}
	else
	{
		frameinfo.ID=((DWORD)FrameID[2]<<8)+((DWORD)FrameID[3]);		
	}
	frameinfo.SendType=m_ComboSendType.GetCurSel();

	VCI_SetReference(m_devtype,m_devind,m_cannum,4,&m_sendTimeout);//���÷��ͳ�ʱ

	int ret = VCI_Transmit(m_devtype,m_devind,m_cannum,&frameinfo,1);
	if(ret==1)
	{
		ShowInfo("д��ɹ�",0);		
	}
	else
	{
		ShowInfo("д��ʧ��",2);		
	}
	
}

void CTestDlg::ShowInfo(CString str, int code)
{
	m_ListInfo.InsertString(m_ListInfo.GetCount(),str);
	m_ListInfo.SetCurSel(m_ListInfo.GetCount()-1);
}

//-----------------------------------------------------
//������
//str��Ҫת�����ַ���
//data������ת�����������ݴ�
//len:���ݳ���
//�������ܣ��ַ���ת��Ϊ���ݴ�
//-----------------------------------------------------
int CTestDlg::strtodata(unsigned char *str, unsigned char *data,int len,int flag)
{
	unsigned char cTmp=0;
	int i=0;
	for(int j=0;j<len;j++)
	{
		if(chartoint(str[i++],&cTmp))
			return 1;
		data[j]=cTmp;
		if(chartoint(str[i++],&cTmp))
			return 1;
		data[j]=(data[j]<<4)+cTmp;
		if(flag==1)
			i++;
	}
	return 0;
}

//-----------------------------------------------------
//������
//chr��Ҫת�����ַ�
//cint������ת������������
//�������ܣ��ַ�ת��Ϊ����
//-----------------------------------------------------
int CTestDlg::chartoint(unsigned char chr, unsigned char *cint)
{
	unsigned char cTmp;
	cTmp=chr-48;
	if(cTmp>=0&&cTmp<=9)
	{
		*cint=cTmp;
		return 0;
	}
	cTmp=chr-65;
	if(cTmp>=0&&cTmp<=5)
	{
		*cint=(cTmp+10);
		return 0;
	}
	cTmp=chr-97;
	if(cTmp>=0&&cTmp<=5)
	{
		*cint=(cTmp+10);
		return 0;
	}
	return 1;
}

UINT CTestDlg::ReceiveThread(void *param)
{
	CTestDlg *dlg=(CTestDlg*)param;
	CListBox *box=(CListBox *)dlg->GetDlgItem(IDC_LIST_INFO);
	//VCI_CAN_OBJ frameinfo[50];
	VCI_ERR_INFO errinfo;
	int len=1;
	int length;
	int i=0;
	CString str,tmpstr;
	while(1)
	{
		Sleep(1);
		if(dlg->m_connect==0)
			break;
		length = VCI_GetReceiveNum(dlg->m_devtype,dlg->m_devind,dlg->m_cannum);
		if (length <=0)
		{
			continue;
		}
		PVCI_CAN_OBJ frameinfo = new VCI_CAN_OBJ[length];
		len=VCI_Receive(dlg->m_devtype,dlg->m_devind,dlg->m_cannum,frameinfo,length,200);
		if(len<=0)
		{
			//ע�⣺���û�ж��������������ô˺�������ȡ����ǰ�Ĵ����룬
			//ǧ����ʡ����һ������ʹ����ܲ���֪����������ʲô��
			VCI_ReadErrInfo(dlg->m_devtype,dlg->m_devind,dlg->m_cannum,&errinfo);
		}
		else
		{
			for(i=0;i<len;i++)
			{
				str="���յ�����֡:  ";
				if(frameinfo[i].TimeFlag==0)
					tmpstr="ʱ���ʶ:��  ";
				else
					tmpstr.Format("ʱ���ʶ:%08x ",frameinfo[i].TimeStamp);
				str+=tmpstr;
				tmpstr.Format("֡ID:%08x ",frameinfo[i].ID);
				str+=tmpstr;
				str+="֡��ʽ:";
				if(frameinfo[i].RemoteFlag==0)
					tmpstr="����֡ ";
				else
					tmpstr="Զ��֡ ";
				str+=tmpstr;
				str+="֡����:";
				if(frameinfo[i].ExternFlag==0)
					tmpstr="��׼֡ ";
				else
					tmpstr="��չ֡ ";
				str+=tmpstr;
				box->InsertString(box->GetCount(),str);
				if(frameinfo[i].RemoteFlag==0)
				{
					str="����:";
					if(frameinfo[i].DataLen>8)
						frameinfo[i].DataLen=8;
					for(int j=0;j<frameinfo[i].DataLen;j++)
					{
						tmpstr.Format("%02x ",frameinfo[i].Data[j]);
						str+=tmpstr;
					}
					//EnterCriticalSection(&(dlg->m_Section));
					//LeaveCriticalSection(&(dlg->m_Section));
					box->InsertString(box->GetCount(),str);
				}				
			}
			box->SetCurSel(box->GetCount()-1);
		}
		delete [] frameinfo;
	}
	return 0;
}

// void CTestDlg::OnMenuRefresh() 
// {
// 	// TODO: Add your command handler code here
// }


void CTestDlg::OnSelchangeComboFilter() 
{
	// TODO: Add your control notification handler code here
	if (m_ComboFilterMode.GetCurSel()==2)
	{
		GetDlgItem(IDC_EDIT_STARTID)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_ENDID)->EnableWindow(FALSE);
	}
	else
	{
		GetDlgItem(IDC_EDIT_STARTID)->EnableWindow(TRUE);
		GetDlgItem(IDC_EDIT_ENDID)->EnableWindow(TRUE);
	}
	
}

void CTestDlg::OnSelchangeComboBaud() 
{
	// TODO: Add your control notification handler code here
	int index = m_ComboBaud.GetCurSel();
	if (index==10)
	{
		GetDlgItem(IDC_EDIT_BTR)->EnableWindow(TRUE);
	} 
	else
	{
		GetDlgItem(IDC_EDIT_BTR)->EnableWindow(FALSE);
		m_strBTR.Format("%08x",GCanBrTab[index]);
		UpdateData(FALSE);
	}
	
}
